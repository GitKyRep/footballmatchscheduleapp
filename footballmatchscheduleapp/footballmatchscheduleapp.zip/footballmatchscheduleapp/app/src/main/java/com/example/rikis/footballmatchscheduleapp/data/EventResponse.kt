package com.example.rikis.footballmatchscheduleapp.data

import com.example.rikis.footballmatchscheduleapp.data.Event

data class EventResponse(val events:List<Event>)