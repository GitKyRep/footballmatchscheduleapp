package com.example.rikis.footballmatchscheduleapp.data


import com.google.gson.annotations.SerializedName

data class Team(
        @SerializedName("strTeamBadge")
        var strTeamBadge:String? = null

)