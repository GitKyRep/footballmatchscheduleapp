package com.example.rikis.footballmatchscheduleapp.data

import com.example.rikis.footballmatchscheduleapp.data.Team

data class TeamResponse(val teams:List<Team>)